from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from .. items import PhylrichItem


class Phylrich(CrawlSpider):

    name = "phylrich"

    #start_urls = [ "https://phylrich.com/collections" ]
    start_urls=["https://phylrich.com/collections/"]

    img_link = "https:"

    main_page_request = "https://phylrich.com/collections/category_here?page=page_number"

    rules = (
        Rule( LinkExtractor(restrict_css=(".flex.row.flex-wrap.items-stretch a:first-child")),callback="category_page" ),
    )


    def category_page(self,response):

        products_page_link = response.css(".thumbnail-overlay a::attr(href)").extract()

        if products_page_link:

            for link in products_page_link:
                yield response.follow(link,callback=self.product_main_page)

            category_name = response.url.split("collections/")[1]

            try:
                category_name = category_name.split("?page")[0]
            except:
                pass

            for page_number in range(2,11):

                temp = self.main_page_request
                temp = temp.replace("category_here",category_name)

                temp = temp.replace("page_number",str(page_number))

                yield Request(url=temp,callback=self.category_pagination)

    def category_pagination(self,response):

        products_page_link = response.css(".thumbnail-overlay a::attr(href)").extract()

        if products_page_link:

            for link in products_page_link:
                yield response.follow(link,callback=self.product_main_page)


    def product_main_page(self,response):

        varient_link = "?variant=swap_varient"        
        
        varients = response.css(".select select[name='id'] option::attr(value)").extract()

        for varient in varients:
            temp = varient_link
            temp = temp.replace("swap_varient",str(varient))
            yield Request(url= response.url + temp, callback=self.main_page)

    def main_page(self,response):

        product = PhylrichItem()

        varient_code = response.css(".sku span::text").extract_first()

        product["finish"] = response.css(f"option[data-sku='{varient_code}']::text").extract_first()
        product["price"] = response.css(".current_price  span::text").extract_first().strip("\n ")
        product["productID"] = varient_code
        product["name"] = response.css(".product_name::text").extract_first()
        product["url"] = response.url


        count = 0

        for index in response.css("select[name='id'] option::text").extract():

            if index ==  product["finish"]:

                check_img = response.css(f"img[data-index='{count}']::attr(src)").extract_first()

                if check_img:

                    product["image"] = self.img_link + check_img
                    product["image"] = product["image"].replace("100x","2000x")
                else:
                    product["image"] = self.img_link + response.css("img[data-index='0']::attr(src)").extract_first()
                    product["image"] = product["image"].replace("100x","2000x")

                break
            
            count += 1
     

        yield product

